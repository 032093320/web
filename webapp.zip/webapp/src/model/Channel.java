package model;

public class Channel {

}
