/*
 * window load event
 */
window.onload = function(){
	init();
}

/*
 * initialize the window
 */
function init(){
	if (typeof(Storage) !== "undefined") {
	    sessionStorage.setItem("id",0);
	    sessionStorage.setItem("indent", 0); 
	    sessionStorage.setItem("user", "");
	} else {
	    alert("your web browser does not support app!");
	}
}

$(document).ready(function(){
    $("#snd").click(function(){
    	var temp = sessionStorage.getItem("id");
    	var offset = "0px";
    	temp++;
    	sessionStorage.setItem("id",temp);
    	var id = sessionStorage.getItem("id");
    	var msg = $('textarea#message').val();
        addItem(msg,id,0,offset);
        
        //clear textarea
        $('textarea#message').val("");
    });
});

/*
 * add new item to the conversation list
 */
function addItem(msg, id, index, offset){
	
	var ul = document.getElementById("list");
	var li = document.createElement("li");
	/*var childArray = ul.childnodes*/
	li.appendChild(document.createTextNode(msg));
	
	li.setAttribute("id","li" + id);
	li.style.paddingLeft = offset;
	/*ul.appendChild(li);*/
	ul.insertBefore(li, ul.childNodes[index]);
	createReplyButton(id);
}

/*
 * insert message to a specific index
 */
function insertAtIndex(id, msg, index){
	alert("id: "+id+" msg: "+msg+" index: "+index);
	var itemId = "li"+id;
	var nextId = parseInt(id);
	nextId++;
	var ul = document.getElememtById("list");
	var node = document.createElement("LI");             // Create a <li> node
	var textnode = document.createTextNode(msg);         // Create a text node
	node.appendChild(textnode);
	node.setAttribute("id", "Li"+nextId);
	/*$("ul li:eq(" + index + ")").after($(node.id));*/
	/*ul.insertBefore(node, ul.childNodes[index]);*/
	ul.appendChild(node);
	
}

/*
 * create a new list item
 */
function createListItem(msg, id){
	var node = document.createElement("LI");             // Create a <li> node
	var textnode = document.createTextNode(msg);         // Create a text node
	node.setAttribute("id", "Li"+id);
	node.appendChild(textnode); 
	alert(node.id);
	return node;
}

/*
 * create reply button
 */
function createReplyButton(id){
	var node = document.getElementById("li"+id);
	alert(node);
	var btn = document.createElement("a");
	btn.setAttribute("id", "btn"+id); 
	btn.setAttribute("href", "#message"); 
	btn.setAttribute("class", "repltBtnClass"); 
	btn.setAttribute("onclick", "openReply("+id+")");  
	btn.innerHTML = "reply";
	node.appendChild(btn);
}

/*
 * create text area for reply
 */
function createReplyTextArea(id){
	var input = document.createElement("textarea");
	input.name = "post" + id;
	input.id = "textID"+id;
	input.maxLength = "500";
	input.rows = "5";
	return input;
}

/*
 * create close button
 */
function createCloseButton(id){
	var button = document.createElement("button");
	
	button.onclick = function() {close(id)};
	button.innerHTML="close";
	button.id = "closeBtn" + id;
	
	return button;
}

/*
 * reply to the list item fired up the event
 */
function openReply(id){
	var itemId = "li"+id;
	var listItem = document.getElementById(itemId); 
	var replyMsg = listItem.innerHTML;	
	var div = document.createElement("div");
	var input = createReplyTextArea(id);
	var button = createCloseButton(id);

	div.id = "div"+id;
	div.appendChild(input); //appendChild
	div.appendChild(button);
	
	listItem.appendChild(div);
}

/*
 * send reply
 */
function sendReply(msg){
	
}

/*
 * generic close btn
*/
function close(id){
	var msgId = "li"+id;
	
	var replyId = "div"+id;
	var textId = "textID"+id;
	var node = document.getElementById(msgId); 	
	var child = document.getElementById(replyId); 
	var replyText = document.getElementById(textId).value;
	var index = getIndex(id);
	var offset = node.style.paddingLeft;
	alert(offset);
	var newoffset = parseInt(offset,10) + 10 +'px';
	alert(newoffset);
	
	child.parentNode.removeChild(child);
	addItem(replyText,id+1,index+1, newoffset); 
}

/*
* get item index
*/
function getIndex(id){
	var itemId = "li"+id;
	var node = document.getElementById(itemId); 
	var index = $("li").index(node);
	return index;
}