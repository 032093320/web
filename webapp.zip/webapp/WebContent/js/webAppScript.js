var wsUri = "ws://localhost:8080/webapp/message"; 
	
function messageWebSocket(msg)
{
  	websocket = new WebSocket(wsUri);
  	websocket.onopen = function(evt) { onOpen(msg) };
  	websocket.onclose = function(evt) { onClose(evt) };
  	websocket.onmessage = function(evt) { onMessage(evt) };
  	websocket.onerror = function(evt) { onError(evt) };
}

function onOpen(evt)
{
  	writeToScreen("CONNECTED");
  	doSend(evt);
}
function onClose(evt)
{
  	writeToScreen("DISCONNECTED");
}
function onMessage(evt)
{
  	writeToScreen('<span style="color: blue;">RESPONSE: ' + evt.data+'</span>');
  	websocket.close();
}
function onError(evt)
{
	writeToScreen('<span style="color: red;">ERROR:</span> ' + evt.data);
}
function doSend(message)
{
  	writeToScreen("SENT: " + message);
  	websocket.send(message);
}
function writeToScreen(message)
{
  	var pre = document.createElement("p");
  	pre.style.wordWrap = "break-word";
  	pre.innerHTML = message;
  	document.getElementById("testMsg").appendChild(pre);
} 

/* 
* window load event
*/
window.onload = function(){

	init();
}

/*
 * initialize the window
 */
function init(){
	if (typeof(Storage) !== "undefined") {
	    sessionStorage.setItem("id",0);
	    sessionStorage.setItem("indent", 0); 
	    sessionStorage.setItem("user", "guest");
	} else {
	    alert("your web browser does not support app!");
	}
}


$(document).ready(function(){
    $("#snd").click(function(){
    	var temp = sessionStorage.getItem("id");
    	var offset = "0px";
    	temp++;
    	sessionStorage.setItem("id",temp);
    	var id = sessionStorage.getItem("id");
    	var msg = $('textarea#message').val();
    	var obj = createMessage(msg);
        addItem(msg,id,0,offset);
        
        //clear textarea and send message to srver
        //alert(obj);
        sendMessage(msg);
        $('textarea#message').val("");
    });
});

/*
 * add new item to the conversation list
 */
function addItem(msg, id, index, offset){
	var ul = document.getElementById("list");
	var li = document.createElement("li");
	/*var childArray = ul.childnodes*/
	li.appendChild(document.createTextNode(msg));
	
	li.setAttribute("id","li" + id);
	li.style.paddingLeft = offset;
	/*ul.appendChild(li);*/
	ul.insertBefore(li, ul.childNodes[index]);
	/*ul.append(li);*/
	createReplyButton(id);
}

/*
 * insert message to a specific index
 * TODO: erase if not used
 */
function insertAtIndex(id, msg, index){
	//alert("id: "+id+" msg: "+msg+" index: "+index);
	var itemId = "li"+id;
	var nextId = parseInt(id);
	nextId++;
	var ul = document.getElememtById("list");
	var node = document.createElement("LI");             // Create a <li> node
	var textnode = document.createTextNode(msg);         // Create a text node
	node.appendChild(textnode);
	node.setAttribute("id", "Li"+nextId);

	ul.appendChild(node);
	
}

/*
 * create a new list item
 */
function createListItem(msg, id){
	var node = document.createElement("LI");             // Create a <li> node
	var textnode = document.createTextNode(msg);         // Create a text node
	node.setAttribute("id", "Li"+id);
	node.appendChild(textnode); 
	return node;
}

/*
 * create reply button
 */
function createReplyButton(id){
	var node = document.getElementById("li"+id);
	var btn = document.createElement("a");
	btn.setAttribute("id", "btn"+id); 
	btn.setAttribute("href", "#message"); 
	btn.setAttribute("class", "repltBtnClass"); 
	btn.setAttribute("onclick", "openReply("+id+")");  
	btn.innerHTML = "reply";
	node.appendChild(btn);
}

/*
 * create text area for reply
 */
function createReplyTextArea(id){
	var input = document.createElement("textarea");
	input.name = "post" + id;
	input.id = "textID"+id;
	input.maxLength = "500";
	input.rows = "5";
	return input;
}

/*
 * create close button
 */
function createCloseButton(id){
	var button = document.createElement("button");
	
	button.onclick = function() {close(id)};
	button.innerHTML="close";
	button.id = "closeBtn" + id;
	
	return button;
}

/*
 * reply to the list item fired up the event
 */
function openReply(id){
	var itemId = "li"+id;
	var listItem = document.getElementById(itemId); 
	var replyMsg = listItem.innerHTML;	
	var div = document.createElement("div");
	var input = createReplyTextArea(id);
	var button = createCloseButton(id);

	div.id = "div"+id;
	div.appendChild(input); //appendChild
	div.appendChild(button);
	
	sendMessage(replyMsg);
	listItem.appendChild(div);
}

/*
 * send reply to server
 */
function sendMessage(msg){
	var obj = createMessage(msg);
	messageWebSocket(JSON.stringify(obj)); 
}

/*
 * generic close btn
*/
function close(id){
	var msgId = "li"+id;
	
	var replyId = "div"+id;
	var textId = "textID"+id;
	var node = document.getElementById(msgId); 	
	var child = document.getElementById(replyId); 
	var replyText = document.getElementById(textId).value;
	var index = getIndex(id);
	var offset = node.style.paddingLeft;
	var newoffset = parseInt(offset,10) + 10 +'px';
	
	child.parentNode.removeChild(child);
	addItem(replyText,id+1,index+1, newoffset); 
}

/*
* get item index
*/
function getIndex(id){
	var itemId = "li"+id;
	var node = document.getElementById(itemId); 
	var index = $("li").index(node);
	return index;
}

/*
* create a message object to be sent
*/
function createMessage(msg){
	
	var obj = {
			 id : 1,
			 user : sessionStorage.getItem("user"),
			 timeStamp : new Date(),
			 content : msg,
			 isReplyable : 1,
			 replyedTo : 0,
			 offset : 0
	};
	return obj;
}
