var wsUri = "ws://localhost:8080/webapp/message"; 
	
function messageWebSocket(msg)
{
  	websocket = new WebSocket(wsUri);
  	websocket.onopen = function(evt) { onOpen(msg) };
  	websocket.onclose = function(evt) { onClose(evt) };
  	websocket.onmessage = function(evt) { onMessage(evt) };
  	websocket.onerror = function(evt) { onError(evt) };
}

function onOpen(evt)
{
  	writeToScreen("CONNECTED");
  	doSend(evt);
}
function onClose(evt)
{
  	writeToScreen("DISCONNECTED");
}
function onMessage(evt)
{
  	writeToScreen('<span style="color: blue;">RESPONSE: ' + evt.data+'</span>');
  	websocket.close();
}
function onError(evt)
{
	writeToScreen('<span style="color: red;">ERROR:</span> ' + evt.data);
}
function doSend(message)
{
  	writeToScreen("SENT: " + message);
  	websocket.send(message);
}
function writeToScreen(message)
{
  	var pre = document.createElement("p");
  	pre.style.wordWrap = "break-word";
  	pre.innerHTML = message;
  	document.getElementById("testMsg").appendChild(pre);
} 

/* 
* window load event
*/
window.onload = function(){

	init();
}

/*
 * initialize the window
 */
function init(){
	if (typeof(Storage) !== "undefined") {
	    sessionStorage.setItem("id",0);
	    sessionStorage.setItem("indent", 0); 
	    sessionStorage.setItem("user", "guest");
	} else {
	    alert("your web browser does not support app!");
	}
}


$(document).ready(function(){
    $("#snd").click(function(){
    	/*if (sessionStorage.getItem("user")=="guest")
    	{
    		alert("must be loged in to send messages!");
    		$("textarea#message").val("");
    	}*/
    	
    		
    	/*else{*/
    		var mxIndex = document.getElementById("list").childNodes.length+1;
        	var offset = "0px";
        	var msg = $("textarea#message").val();
            addItem(msg,0,mxIndex,offset,"",0);
            
            //clear text area and send message to server
            $('textarea#message').val("");
    	/*}*/
    });
});

/*
 * add new item to the conversation list, and send it to the server
 */
function addItem(msg, id, index, offset, user, repliedToId){
	
	var id = incrementId();
	var ul = document.getElementById("list");
	var li = document.createElement("li");
	var time = new Date();
	var userNode = createUserNode("user");
	var timeString = document.createTextNode(time + "posted: "); 
	var btn = createReplyButton(id);
	var msgObj;
	
	li.appendChild(userNode);
	li.appendChild(timeString);
	li.appendChild(document.createTextNode(msg));
	li.appendChild(btn);
	
	li.setAttribute("id","li" + id);
	li.style.paddingLeft = offset;
	ul.insertBefore(li, ul.childNodes[index]);
	document.getElementById("message").value = "";

	msgObj = createMessage(msg, time, 1, repliedToId, offset);
	alert(JSON.stringify(msgObj)); 
	/*sendMessage(msg);*/
}

/*
* create a message object to be sent
*/
function createMessage(msg, time, replyable, repliedToId, offset){
	 var m_id = sessionStorage.getItem("id"); 
	 var m_user = sessionStorage.getItem("user");
	alert("msg created");
	var obj = {
			 id : m_id,
			 user : m_user,
			 timeStamp : time,
			 content : msg,
			 isReplyable : replyable,
			 replyedTo : repliedToId,
			 offset : offset
	};
	return obj;
}

/*
 * generic close btn
*/
function close(btn){
	var id = (btn.id).substring(8);		//what id the reply came from
	id = parseInt(id);
	var msgId = "li"+id;
	
	var replyId = "div"+id;
	var textId = "textID"+id;
	var node = document.getElementById(msgId); 	
	var child = document.getElementById(replyId); 
	var replyText = document.getElementById(textId).value;
	var index = getIndex(id);
	var offset = node.style.paddingLeft;
	var newoffset = parseInt(offset,10) + 10 +'px';
	
	child.parentNode.removeChild(child);
	addItem(replyText,0,index+1, newoffset,sessionStorage.getItem("user"),id); 
}

/*
 * adjust id count
 */
function incrementId(){
	var id = sessionStorage.getItem("id");
	id = parseInt(id) +1;
	sessionStorage.setItem("id",id); 
	return id;
}

/*
 * create user reply button
 */
function createUserNode(user){
	var userName = document.createElement("a");
	userName.innerHTML = ('@' + user); 
	userName.setAttribute("href", "#message");
	userName.setAttribute("onclick", "userClicked("+user+")");
	
	return userName;
}

/*
 * user clicked
 */
function userClicked(user){
	alert(user);
}

/*
 * insert message to a specific index
 * TODO: erase if not used
 */
function insertAtIndex(id, msg, index){
	//alert("id: "+id+" msg: "+msg+" index: "+index);
	var itemId = "li"+id;
	var nextId = parseInt(id);
	nextId++;
	var ul = document.getElememtById("list");
	var node = document.createElement("LI");             // Create a <li> node
	var textnode = document.createTextNode(msg);         // Create a text node
	node.appendChild(textnode);
	node.setAttribute("id", "Li"+nextId);

	ul.appendChild(node);
	
}

/*
 * create a new list item
 */
function createListItem(msg, id){
	var node = document.createElement("LI");             // Create a <li> node
	var textnode = document.createTextNode(msg);         // Create a text node
	node.setAttribute("id", "Li"+id);
	node.appendChild(textnode); 
	return node;
}

/*
 * create reply button
 */
function createReplyButton(id){
	var btn = document.createElement("a");
	btn.setAttribute("id", "btn"+id); 
	btn.setAttribute("href", "#message"); 
	btn.setAttribute("class", "repltBtnClass"); 
	btn.setAttribute("onclick", "openReply("+id+")");  
	btn.innerHTML = "reply";
	return btn;
}

/*
 * create text area for reply
 */
function createReplyTextArea(id){
	var input = document.createElement("textarea");
	input.name = "post" + id;
	input.id = "textID"+id;
	input.maxLength = "500";
	input.rows = "5";
	return input;
}

/*
 * create close button
 */
function createCloseButton(id){
	var button = document.createElement("button");
	
	button.onclick = function() {close(this)};
	button.innerHTML="close";
	button.id = "closeBtn" + id;
	
	return button;
}

/*
 * reply to the list item fired up the event
 */
function openReply(id){
	
	var itemId = "li"+id;
	var listItem = document.getElementById(itemId); 
	var replyMsg = listItem.innerHTML;	
	var div = document.createElement("div");
	var input = createReplyTextArea(id);
	var button = createCloseButton(id);
	var index = getIndex(id); 

	div.id = "div"+id;
	div.appendChild(input); //appendChild
	div.appendChild(button);
	
	/*sendMessage(replyMsg);*/
	listItem.appendChild(div);	
}

/*
 * send reply to server
 */
function sendMessage(msg){
	messageWebSocket(JSON.stringify(obj)); 
}

/*
* get item index
*/
function getIndex(id){
	
	var arr = document.getElementById("list").childNodes;
	var length =  arr.length;
	var i = 0;
	var itemId = "li"+id;
	
	while(i<length){
		if(arr[i].id === itemId)
			return i;
		else{
			i++; 
		}
	}
	return -1;
}


