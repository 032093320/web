/**************************************************/
/*this is where the app functionality takes place */
/*all function JQuery and standard functions 	  */
/*												  */
/* last modified by: shahar aizikovitz			  */
/* 			   date: 19.2.2017				   	  */
/**************************************************/

/* VARIABLES: */
/*------------*/
var wsUri = "ws://localhost:8080/webapp/message";		//message socket address
var userServletUrl = "http://localhost:8080/webapp/UserServlet";
var LoginServletUrl = "http://localhost:8080/webapp/LoginServlet";
var messageId;
var messageOffset;

/* FUNCTIONS: */
/*------------*/ 

/* functions to handle web socket functionality*/
function messageWebSocket(msg)
{
  	websocket = new WebSocket(wsUri);
  	websocket.onopen = function(evt) { onOpen(msg) };
  	websocket.onclose = function(evt) { onClose(evt) };
  	websocket.onmessage = function(evt) { onMessage(evt) };
  	websocket.onerror = function(evt) { onError(evt) };
}
function onOpen(evt)
{
  	writeToScreen("CONNECTED");
  	doSend(evt);
}
function onClose(evt)
{
  	writeToScreen("DISCONNECTED");
}
function onMessage(evt)
{
	var obj = JSON.parse(evt.data);
	var messageOffset = obj["offset"]; 
	var messageId = obj["id"];
	var msg = obj["content"]; 
	
	alert("line 43: message offset" + messageOffset + " message id:" + messageId + "msg: "+ msg); 
	sessionStorage.setItem("ID", messageId);
	sessionStorage.setItem("OFFSET", messageOffset);
	
	var id = sessionStorage.getItem("ID");
	var offset = sessionStorage.getItem("OFFSET");
	alert("line 51: message offset" + offset + " message id:" + id); 
	//TODO: erase later, after fixing messages coming-in in a delay
	
	
  	writeToScreen('<span style="color: blue;">RESPONSE: ' + obj + '</span>');
  	
  	websocket.close();
}
function onError(evt)
{
	writeToScreen('<span style="color: red;">ERROR:</span> ' + evt.data);
}
function doSend(message)
{
  	writeToScreen("SENT: " + message);	//writes to page for control, to be deleted
  	websocket.send(message);
}
function writeToScreen(message)
{
  	var pre = document.createElement("p");
  	pre.style.wordWrap = "break-word";
  	pre.innerHTML = message;
  	document.getElementById("testMsg").appendChild(pre);
}



/*append a new message to view dynamically, message is an object consist of 1 row and 3 columns
 * of equal size, each contain a paragraph. each message has a user label, paragraph for message and reply button*/
 function createMessage(msg, id){

	 //TODO: erase later
		return "<div class='container' id='msg" + id + "' style='border-style: none none solid none; position:relative; left: 5px; background-color:white'>\n" + 
					"<p hidden id='id'>" + id +"</p>\n" + 
					"<div class='col-sm-2'>\n" + 
						"<p><span class='label label-primary' style='paddingLeft:0px'>user name:</span></p>\n" + 
					"</div>\n" + 
					"<div class='col-sm-8'>\n" + 
					//TODO:erase later
						"<div class='container'>" + msg + id + "</div>\n" + 
					"</div>\n" + 
					"<div class='col-sm-2'>\n" + 
						"<p><a id='reply" + id + "'href='#msg' onclick='handleReply(" + id + ")' style='paddingRight=0px'>reply</a></p>\n" + 
					"</div>\n" +
				"</div>\n" + 
				"<br>\n" + 
				"<div class='container' id='replyMsg"+id+ "' hidden style='position:relative; left:5px'>\n" +
					"<button type='button' class='close' onclick='closeReplyText("+ id +");'>&times;</button>\n" +
					"<textarea class='form-control' rows='4' id='replyArea" + id + "'></textarea>\n" +
					"<br>\n" + 
				"</div>"; 	
	}

 /********************************* handle close reply area event and send msg ****************/
 function closeReplyText(id){
	 var replyMsgId = "replyMsg" + id; 
	 var reply = document.getElementById(replyMsgId);
	 var rplyId = "reply" + id;

	 reply.style.display = "none";
	 document.getElementById(rplyId).innerHTML = "reply"; 
 }

 /************************************** handle reply ************************************/ 
 function handleReply(id){
	var msgId = "msg" + id;													//msg being replied to (msg container)
 	var replyMsgId = "replyMsg" + id;										//reply container id
 	var rplyId = "reply" + id;												//the button firing up reply id
 	var replyAreaId = "replyArea" + id; 									//reply text area id
	var replyContext = document.getElementById(replyAreaId).value;			//reply text area element		 
 	var reply = document.getElementById(replyMsgId);						//reply container element
 	var replyControlText = document.getElementById(rplyId).innerHTML;		//reply button, to change text
 	var newChild = createMessage(replyContext, id);
 	var div = document.getElementById(msgId);
 	var style = getComputedStyle(div);
 	var new_left = parseInt(style.left, 10);
 	new_left = new_left + 30;
 	alert(new_left);		//TODO: remove later
 	/*var iDiv = Document.createElement(createMessage(replyContext,id));*/ 
 	
 	if (replyControlText=="send"){
 		document.getElementById(rplyId).innerHTML = "reply"; 
 		reply.style.display = "none";
 		addMessage(replyContext,id);
 		document.getElementById(replyContext).style.left = new_left+"px"; 
 	}
 	if (replyControlText=="reply"){
 		document.getElementById(rplyId).innerHTML = "send";
 		reply.style.display = "block";
 	}
 	
 	alert(offset + rplyId); 
 	/*document.getElementById(msgId).style.left = "100px";
 	alert("offset: " + offset);
 	sessionStorage.setItem("reply", 1); 
 	sessionStorage.setItem("offset", offset); 
 	alert("is reply: " + sessionStorage.getItem("reply"));*/
 }
 
 /************************************** validate user details ******************************/ 
function validate(text, id){
		var location = text.indexOf(",");
		var count = text.length;
		
		if (count>=10){
			alert("too many charachters' only 10 allowed");
		}
		if(location != -1){
			 alert("can't use the charrachter: ','");
			 document.getElementById(id).value = "";
		 }
	}

/*create json object from user forms text/input fields*/
function createUserObject(my_form){
		var arr = my_form.getElementsByTagName("input"); 
		var um = arr[0].value;
		var pw = arr[1].value;
		var nm = arr[2].value;
		var ds = arr[3].value;
		var ph = arr[4].value; 
		
		var Obj = {
					userName : um,
					password : pw,
					nickName : nm,
					description : ds,
					photo : ph
				   };
		//TODO: erase when done
		alert("user:" + um + "pass:" + pw + "nickname:" + nm + "description:" + ds + "photo:" + ph); 
		return Obj;
	}



$(document).ready(function(){
	
/**************************** registration or login handling ************************/
	 $("#rgstrBtn").click(function(){
		var my_form = document.getElementById("frm");
		var url = 'http://localhost:8080/webapp/UserServlet' + '?query=insert';		
		var msg = (createUserObject(my_form));
		/*TODO: check form fields before sending to server*/
		alert(JSON.stringify(msg));
		$.post(	url,
				JSON.stringify(msg),
				function(data){
		});
	});
	 
/**************************** handle new messages creating **************************/
	 $("#sndmsg").click(function(event){		  
		event.preventDefault();
		if(localStorage.getItem("username") == null)
		{
			alert("must be logged in");
			return;
		}

		
		/*var m_id = 1;					//TODO: add code here to handle msg counter
		var name = localStorage.getItem("username"); 
		var dt = (new Date()); 		//Date(year, month, day, hours, minutes, seconds, milliseconds); 
		var msg = $("#msg").val();	//the message
		var reply = 0;
		var replyTo = "you";		//TODO: get name of the user that wrote the msg replyed to
		var offset = 1;				//TODO: find msg replyed to and increase indent by 1
		
		/*if(sessionStorage.getItem("reply") == 1)
		{
			offset = sessionStorage.getItem("offset");
			alert(offset);
			sessionStorage.setItem("reply", 0);
		}*/
		
		/*var obj = {	
					id: 0, 
					user: localStorage.getItem("username"),
					timeStamp: (new Date()), 
					content: msg,
					isReplyable: 0,
					replyedTo: 0,
					offset: 5
					};*/
		var msg = cretaeLastMessage(); 
		if(msg["content"]=="") alert("message is empty");
		else
			{
			
				/*reset message text*/
				$("#msg").val("");

				/*send to the server via message web socket
				alert(JSON.stringify(msg));
				messageWebSocket(JSON.stringify(msg));*/

				/*append to view*/
				/*$("#conversation").append(createMessage(msg["content"], sessionStorage.getItem("ID")));*/
				addMessage(msg["content"], sessionStorage.getItem("ID")); 
			}
	 });

/*********************************** login handling **********************************/
	 $("#lgBtn").click(function(){
		 var frm = document.getElementById("lg_frm");
		 var inputArr = frm.getElementsByTagName("input");
		 var username = inputArr[0].value;
		 var password = inputArr[1].value;
		 var url = userServletUrl + '?query=select&username=' + username +'&password=' + password; 
		 $.post(url,
				function(data){
			 if (data == null) alert("problems..");
			 var obj = JSON.parse(data);
			 var user = {
					 userName: obj.userName,
					 password: obj.password,
					 nickName: obj.nickName,
					 description : obj.description,
					 photo : obj.photo
			 }
			 createCurrentUser(obj);
		 });
		 
		 //TODO: reset login user and password fields
	 });
	 
});

/*
 * insert a new message to conversation
 */
function addMessage(msg, id, is_new){
	 var m_content;
	 if(is_new==1){
		 m_content = $("#msg").val();
	 }
	 else{
		 m_content = msg;
	 }
		 
	
	/*var convers = document.getElementById("conversation");
	convers.append(createMessage(msg,id));*/
	
	/*creating the view object to be added*/
	var div = createMessage(m_content,id);
	
	/*send to the server via message web socket*/
	alert(JSON.stringify(div));
	messageWebSocket(JSON.stringify(div));
	
	$("#conversation").append(div); 
	
}

function createCurrentUser(user){
	localStorage.setItem("username", user.userName);
	localStorage.setItem("password", user.password);
	localStorage.setItem("nickName", user.nickName);
	localStorage.setItem("description", user.description);
	localStorage.setItem("photo", user.photo);
}

/* count the length of the message, under 500 characters alert the user and erase overflow*/
 function wordCount(){

 }
 
 /********************************* create last message sent ****************************/ 
 function cretaeLastMessage(msg){
		 
	 var obj =  {	
				id: 0, 
				user: localStorage.getItem("username"),
				timeStamp: (new Date()), 
				content: msg,
				isReplyable: 0,
				replyedTo: 0,
				offset: 5
				};
	 return obj; 
 }
